import UIKit

let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "yyyyMMdd"
let dateStr = "20230101"
let currentDate = dateFormatter.date(from: dateStr)

let calendar = Calendar(identifier: .iso8601)
let range = calendar.range(of: .day, in: .year, for: currentDate!)!
let datesArrInYear = range.compactMap {
    calendar.date(byAdding: .day, value: $0 - 1, to:
    currentDate!)
}

